

for x in range(0):
    print(x)