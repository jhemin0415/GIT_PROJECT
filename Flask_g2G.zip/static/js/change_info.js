function change_email(){
  window.open("/change_email", "", "width=550, height=345");
}


function change_username(){
  window.open("/change_username", "", "width=550, height=345");
}


function change_password(){
  window.open("/change_pw", "", "width=550, height=345");
}
